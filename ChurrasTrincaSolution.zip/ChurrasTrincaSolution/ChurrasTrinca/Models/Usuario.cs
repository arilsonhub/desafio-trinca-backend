﻿namespace ChurrasTrinca.Models
{
    public class Usuario
    {
        public long id { get; set; }
        public string login { get; set; }
        public string senha { get; set; }
    }
}